/**
 * @file stripeColorPicker_private.h
 * @description student declarations of private functions
 *              for StripeColorPicker, CPSC 221 PA2
 *
 *              THIS FILE WILL BE SUBMITTED.
 *
 *              Simply declare your function prototypes here.
 *              No other scaffolding is necessary.
 */

 // begin your declarations below
